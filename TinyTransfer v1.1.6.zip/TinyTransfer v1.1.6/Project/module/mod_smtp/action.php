<?php

use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use system\UI;

// define module-smtp path
define('MODULE_SMTP_PATH', __DIR__ . DS);
define('MODULE_SMTP_VERSION', "1.0.3.20200903");

/**
 * Mailer
 * send Mailer
 */
UI::map('mailer', function ($config = []) {
    // $config = [
    //     "smtp_host"=>"",
    //     "smtp_port"=>"",
    //     "auth_addr"=>"",
    //     "auth_pass"=>"",
    //     "from_name"=>"",
    //     "from_addr"=>"",
    //     "to_name"=>"",
    //     "to_addr"=>"",
    //     "subject"=>"",
    //     "body"=>"",
    // ];
    if (
        empty($config['smtp_host']) ||
        empty($config['smtp_port']) ||
        empty($config['auth_addr']) ||
        empty($config['auth_pass']) ||
        empty($config['from_name']) ||
        empty($config['from_addr']) ||
        empty($config['to_addr'])
    ) {
        return false;
    }

    $mail = new PHPMailer(true);

    try {
        //Server settings SMTP debug
        $mail->SMTPDebug  = 1;// Enable verbose debug output
        $mail->isSMTP(); // Send using SMTP
        $mail->Host = $config['smtp_host']; // Set the SMTP server to send through
        $mail->SMTPAuth = true; // Enable SMTP authentication

        if (isset($config['smtp_secure']) && $config['smtp_secure'] == "false") {
            // $mail->SMTPAutoTLS = false;
            $mail->SMTPSecure  =  PHPMailer::ENCRYPTION_STARTTLS;
        } else {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        }

        $mail->Username = $config['auth_addr']; // SMTP username
        $mail->Password = $config['auth_pass']; // SMTP password
        $mail->Port = $config['smtp_port']; // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

        //Recipients
        $mail->setFrom($config['from_addr'], $config['from_name']);
        $mail->addAddress($config['to_addr']); // Add a recipient

        // Content
        $mail->isHTML(true); // Set email format to HTML
        $mail->Subject = $config['subject'];
        $mail->Body = $config['body'];
        $mail->send();
        return true;
    } catch (\Exception $e) {
        UI::database("Log_Error")->insert([
            "msg" => $mail->ErrorInfo
        ]);
        return false;
    }
});


\module\smtp\Version::init();



// add admin menu
add_menu_page('Smtp Home', 'Smtp', 'setting_smtp_form', function () {
    return \module\smtp\Admin::index();
}, 'icon-emailFilled');

/* routes */
// form api service send
UI::route('POST /mod_smtp/save', [\module\smtp\Admin::class, 'save']);
UI::route('POST /mod_smtp/test', [\module\smtp\Admin::class, 'test']);
