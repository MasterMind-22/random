<?php

return [
    "name" => "module_email",
    "open" => true
];
