/* -------------------------------------------------------------------
 * Author Name           : Bbfpl
 * Author URI            : https://codecanyon.net/user/bbfpl
 * Version               : 1.1.1
 * File Name             : admin.min.js
------------------------------------------------------------------- */

(function($) {
    "use strict";

    function handle_ajax(url, button, data, type, cb) {
        button.addClass('loading');
        button.attr("disabled", "true");
        jQuery.ajax({
            url: url,
            data: JSON.stringify(data),
            contentType: "application/json",
            dataType: "json",
            type: type,
            success: function(response) {
                setTimeout(() => {
                    button.removeClass("loading");
                    button.removeAttr("disabled");
                }, 1000);

                if (response.code == 200) {
                    spop({
                        template: response.msg,
                        position: "top-center",
                        style: "success",
                        autoclose: 1200,
                        onClose: function() {
                            if (cb) {
                                cb(response.data);
                            }
                        }
                    });
                } else {
                    spop({
                        template: response.msg,
                        position: "top-center",
                        style: "error",
                        autoclose: 1200
                    });
                }
            }
        });
    }


    jQuery(document).on("click", ".update-btn", function() {
        let button = jQuery(this);
        // submit data
        let data = {
            smtp_host: jQuery("#smtp_host").val().trim(),
            smtp_port: jQuery("#smtp_port").val().trim(),
            auth_addr: jQuery("#auth_addr").val().trim(),
            auth_pass: jQuery("#auth_pass").val().trim(),
            from_name: jQuery("#from_name").val().trim(),
            from_addr: jQuery("#from_addr").val().trim(),
            smtp_secure: jQuery("#secure").prop("checked") ? "true" : "false"
        };
        handle_ajax("/mod_smtp/save", button, data, "POST");
    });

    jQuery(document).on("click", ".test-settings-toggle-btn", function() {
        jQuery(".test-settings").slideToggle(300);
    });

    jQuery(document).on("click", ".test-send-btn", function() {
        let button = jQuery(this);

        // submit data
        let data = {
            to_addr: jQuery("#test_to_addr").val().trim(),
            subject: jQuery("#test_subject").val().trim(),
            body: jQuery("#test_body").val().trim(),
        };

        handle_ajax("/mod_smtp/test", button, data, "POST");
    });
})(window.jQuery);