<?php

namespace module\smtp;

use system\UI;

/**
 * Version
 */
class Version
{
    protected static $config;

    /**
     * get config
     */
    public static function get_config()
    {
        self::$config = UI::database("Config")->where('type', 'email')->first();
    }
    /**
     * init
     */
    public static function init()
    {
        self::get_config();
        if (self::$config == null) {
            self::insert();
        } else {
            self::update();
        }
    }

    /**
     * insert init db
     */
    public static function insert()
    {
        UI::database("Config")->insert([
            "version"=>MODULE_SMTP_VERSION,
            "type" => "email",
            "smtp_host" => "",
            "smtp_port" => "",
            "auth_addr" => "",
            "auth_pass" => "",
            "from_name" => "",
            "from_addr" => "",
            "to_name" => "",
            "to_addr" => "",
            "subject" => "",
            "body" => "",
            "smtp_secure" => "true",
        ]);
    }

    /**
     * update
     */
    public static function update()
    {
        if (isset(self::$config["version"])) {
            // version update
        } else {
            // old
            UI::database("Config")->where('type', 'email')->update([
                "version"=>MODULE_SMTP_VERSION,
                "smtp_secure" => "true",
            ]);
        }
    }
}
