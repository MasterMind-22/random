<?php

return [
    "name" => "mod_statistics",
    "open" => true
];
