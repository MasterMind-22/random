<?php
use system\UI;

// define module-statistics path
define('MODULE_STATISTICS_PATH', __DIR__ . DS);
