/* -------------------------------------------------------------------
 * Author Name           : Bbfpl
 * Author URI            : https://codecanyon.net/user/bbfpl
 * Version               : 1.0.0
 * File Name             : main.js
------------------------------------------------------------------- */

(function($) {
    "use strict";

    function handle_ajax(url, button, data, type, cb) {
        button.addClass('loading');
        button.attr("disabled", "true");
        jQuery.ajax({
            url: url,
            data: JSON.stringify(data),
            contentType: "application/json",
            dataType: "json",
            type: type,
            success: function(response) {
                setTimeout(() => {
                    button.removeClass("loading");
                    button.removeAttr("disabled");
                }, 1000);

                if (response.code == 200) {
                    spop({
                        template: response.msg,
                        position: "top-center",
                        style: "success",
                        autoclose: 1200,
                        onClose: function() {
                            if (cb) {
                                cb(response.data);
                            }
                        }
                    });
                } else {
                    spop({
                        template: response.msg,
                        position: "top-center",
                        style: "error",
                        autoclose: 1200
                    });
                }
            }
        });
    }

    function pop(msg) {
        spop({
            template: msg,
            position: "top-center",
            style: "error",
            autoclose: 1200
        });
    }
    jQuery(document).on("change", "input[type=radio]", function() {
        jQuery('.tab').removeClass("active");
        jQuery('.tab-' + jQuery(this).val()).addClass("active");
    });

    jQuery(document).on("click", ".update-btn", function() {
        let button = jQuery(this);

        let radio_val = jQuery('input:radio[name=type]:checked').val();
        let data = {
            "upload_type": radio_val
        };
        if (radio_val != "local") {
            data["key"] = jQuery(".tab-" + radio_val).find("input[name=key]").val();
            data["secret"] = jQuery(".tab-" + radio_val).find("input[name=secret]").val();
            data["bucket"] = jQuery(".tab-" + radio_val).find("input[name=bucket]").val();
            data["region"] = jQuery(".tab-" + radio_val).find("input[name=region]").val();
        }
        if (data["key"] == "") {
            pop("key cannot be null.");
            return false;
        }
        if (data["secret"] == "") {
            pop("secret cannot be null.");
            return false;
        }
        if (data["bucket"] == "") {
            pop("bucket cannot be null.");
            return false;
        }
        if (data["region"] == "") {
            pop("region cannot be null.");
            return false;
        }

        handle_ajax("/mod_storage/save", button, data, "POST");
    });
})(window.jQuery);