<?php

return [
    "name" => "mod_storage",
    "open" => true
];
