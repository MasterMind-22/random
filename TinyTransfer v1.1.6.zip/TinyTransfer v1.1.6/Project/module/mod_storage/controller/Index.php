<?php

namespace module\storage;

use system\UI;

/**
 * Index
 */
class Index
{
    /**
     * index
     */
    public static function index()
    {
        $config_storage = UI::database("Config")->where('type', 'storage')->first();
        return UI::fetch(MODULE_STORAGE_PATH . 'view/index.view', [
            "upload_type" => $config_storage["upload_type"],
            "s3"=>$config_storage["s3"],
            "wasabi"=>$config_storage["wasabi"]
        ]);
    }

    /**
     * save
     */
    public static function save()
    {
        if (PREVIEW) {
            return UI::json([
                "code" => 201,
                "msg" => "Preview mode cannot be modified",
            ]);
            exit();
        }
        
        $data = UI::request()->data;
        $config_storage = UI::database("Config")->where('type', 'storage')->first();
        if ($config_storage != null) {
            $upload_type = UI::safe()->esc_attr($data["upload_type"]);
            $update_data=[
                "upload_type"=> $upload_type,
            ];
            if ($upload_type != "local") {
                $update_data[$upload_type] = [
                    "key" => UI::safe()->esc_attr($data["key"]),
                    "secret" => UI::safe()->esc_attr($data["secret"]),
                    "region" => UI::safe()->esc_attr($data["region"]),
                    "bucket" => UI::safe()->esc_attr($data["bucket"]),
                ];
            }

            UI::database("Config")->where('type', 'storage')->update($update_data);
            return UI::json([
                "code" => 200,
                "msg" => "Update successfully!",
            ]);
        } else {
            return UI::json([
                "code" => 201,
                "msg" => "Update failed!",
            ]);
        }
    }
}
