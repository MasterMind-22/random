<?php

namespace module\storage;

use Aws\S3\S3Client;
use League\Flysystem\Filesystem;

use Aws\S3\Exception\S3Exception;

use system\UI;
use module\storage\AwsS3Adapter;

class Storage
{
    public static $file;
    public static $file_path;
    public static $tmp_path;
    public static $chunk;
    public static $chunks;
    public static $security_suffix;

    public static function upload($option=[])
    {
        $md5_ymd = md5(date("Y-m-d", time()));

        self::$file = isset($option["file"]) ? $option["file"] : null;
        self::$file_path = (isset($option["file_path"]) ? $option["file_path"] : 'uploads')  .'/' . $md5_ymd . '/';
        self::$tmp_path = isset($option["tmp_path"]) ? $option["tmp_path"] . DS : TMP_PATH . "_file".DS;
        self::$chunk = isset($option["chunk"]) ? $option["chunk"] : 0;
        self::$chunks = isset($option["chunks"]) ? $option["chunks"] : 1;
        self::$security_suffix = isset($option["security_suffix"]) ? $option["security_suffix"] : '';

        UI::fs()->createFolder(ROOT_PATH . self::$file_path);

        if (!isset($option["tmp_path"])) {
            UI::fs()->createFolder(TMP_PATH . "_file");
        }

        $cleanup_target_dir = true;
        $max_file_age = 60*60*24;

        $file_name = self::$file["name"];
        $old_name = $file_name;
        $file_path = self::$tmp_path . $file_name;

        // Chunking might be enabled
        $chunk = self::$chunk;
        $chunks = self::$chunks;

        // Delete cache checksum
        if ($cleanup_target_dir) {
            if (!is_dir(self::$tmp_path) || !$dir = opendir(self::$tmp_path)) {
                return [
                    "status"=>'error',
                    "msg"=>"Failed to open temp directory"
                ];
            }
            while (($file = readdir($dir)) !== false) {
                $tmpfilePath = self::$tmp_path  . $file;
                // If temp file is current file proceed to the next
                if ($tmpfilePath == "{$file_path}_{$chunk}.part" || $tmpfilePath == "{$file_path}_{$chunk}.parttmp") {
                    continue;
                }
                // Remove temp file if it is older than the max age and is not the current file
                if (preg_match('/\.(part|parttmp|mp4)$/', $file) && (@filemtime($tmpfilePath) < time() - $max_file_age)) {
                    @unlink($tmpfilePath);
                }
            }

            closedir($dir);
        }

        if (!$out = @fopen("{$file_path}_{$chunk}.parttmp", "wb")) {
            return [
                "status"=>'error',
                "msg"=>"Failed to open output stream"
            ];
        }
        if (!empty(self::$file)) {
            if (self::$file["error"] || !is_uploaded_file(self::$file["tmp_name"])) {
                return [
                    "status"=>'error',
                    "msg"=>"Failed to move uploaded file"
                ];
            }
            // Read binary input stream and append it to temp file
            if (!$in = @fopen(self::$file["tmp_name"], "rb")) {
                return [
                    "status"=>'error',
                    "msg"=>"Failed to open input stream"
                ];
            }
        } else {
            if (!$in = @fopen("php://input", "rb")) {
                return [
                    "status"=>'error',
                    "msg"=>"Failed to open input stream"
                ];
            }
        }
        while ($buff = fread($in, 4096)) {
            fwrite($out, $buff);
        }
        @fclose($out);
        @fclose($in);
        rename("{$file_path}_{$chunk}.parttmp", "{$file_path}_{$chunk}.part");
        $index = 0;
        $done = true;
        for ($index = 0; $index < $chunks; $index++) {
            if (!file_exists("{$file_path}_{$index}.part")) {
                $done = false;
                break;
            }
        }
 
        //Upload all files Execute merge files
        if ($done) {
            $path_info = pathinfo($file_name);
            $hash_str = substr(md5($path_info['basename']), 8, 16);
            $hash_name = time() . $hash_str . '.' .$path_info['extension'];
            $upload_path = ROOT_PATH . self::$file_path .$hash_name . self::$security_suffix;

            if (!$out = @fopen($upload_path, "wb")) {
                return [
                    "status"=>'error',
                    "msg"=>"Failed to open output stream"
                ];
            }
            if (flock($out, LOCK_EX)) {
                for ($index = 0; $index < $chunks; $index++) {
                    if (!$in = @fopen("{$file_path}_{$index}.part", "rb")) {
                        break;
                    }
                    while ($buff = fread($in, 4096)) {
                        fwrite($out, $buff);
                    }
                    @fclose($in);
                    @unlink("{$file_path}_{$index}.part");
                }
                flock($out, LOCK_UN);
            }

            @fclose($out);

            $file_size = filesize($upload_path);

            $out_file_path = self::$file_path .$hash_name;

            // oss aws
            $config_storage = UI::database("Config")->where('type', 'storage')->first();
            if ($config_storage && $config_storage["upload_type"] != "local") {
                $disk = self::filesystem($config_storage);
                $fp = fopen($out_file_path, "r");
                $write_stream = $disk->writeStream($out_file_path, $fp);
                if ($write_stream) {
                    if ($config_storage["upload_type"] == "s3") {
                        $out_file_path = 'http://'.$config_storage["s3"]["bucket"].'.s3.'.$config_storage["s3"]["region"].'.amazonaws.com'.DS.$out_file_path;
                    }
                    if ($config_storage["upload_type"] == "wasabi") {
                        $out_file_path = 'http://s3.'.$config_storage["wasabi"]["region"].'.wasabisys.com'.DS.$out_file_path;
                    }
                }
                // remove local file
                @unlink($upload_path);
            }

            $response = [
                "type"=>$config_storage["upload_type"],
                "status"=>'success',
                'old_name'=>$old_name,
                'hash_name'=>$hash_name,
                'file_path'=>self::$file_path .$hash_name,
                'file_path_url'=>$out_file_path,
                'file_suffixes'=>$path_info['extension'],
                'file_size'=>$file_size,
                'security_suffix'=>self::$security_suffix
            ];
            
            return $response;
        } else {
            return [
                "status"=>'pending',
                "chunk"=>$chunk,
                "chunks"=>$chunks,
            ];
        }
    }

    // writeFile
    private static function writeFile($body, $path)
    {
        self::createDir(dirname($path));
        $handle = fopen($path, 'w');
        fwrite($handle, $body);
        fclose($handle);
        return 1;
    }

    // createDir
    private static function createDir($path)
    {
        if (!file_exists($path)) {
            self::createDir(dirname($path));
            mkdir($path, 0777);
        }
    }

    // deldir
    private static function deldir($dir)
    {
        if (!$handle = @opendir($dir)) {
            return false;
        }
        while (false !== ($file = readdir($handle))) {
            if ($file !== "." && $file !== "..") {       //排除当前目录与父级目录
                $file = $dir . '/' . $file;
                if (is_dir($file)) {
                    self::deldir($file);
                } else {
                    @unlink($file);
                }
            }
        }
        @rmdir($dir);
    }

    // download
    public static function download($id, $files, $has_speed_limit=false, $speed_limit_value=102400)
    {
        $config_storage = UI::database("Config")->where('type', 'storage')->first();
        if ($config_storage && $config_storage["upload_type"] != "local") {
            if ($config_storage["upload_type"] == "s3") {
                $bucket = $config_storage["s3"]["bucket"];
            }
            if ($config_storage["upload_type"] == "wasabi") {
                $bucket = $config_storage["wasabi"]["bucket"];
            }
            // The process is to first download to local->compress->download Suitable for small files
            $client = self::filesystem($config_storage, false);

            if (count($files)==1) {
                $cmd = $client->getCommand('GetObject', [
                    'Bucket' => $bucket,
                    'Key' => $files[0]["file_path"],
                    'ResponseContentType'        => 'application/octet-stream',
                    'ResponseContentDisposition' => 'attachment; filename='.$files[0]["old_name"],
                    'ResponseCacheControl'       => 'No-cache',
                    'ResponseExpires'            => gmdate(DATE_RFC2822, time() + 3600),
                ]);
                
                $request = $client->createPresignedRequest($cmd, '+20 minutes');

                // Get the actual presigned-url
                $presignedUrl = (string)$request->getUri();

                UI::redirect($presignedUrl);
            } else {
                // Temporarily does not support multi-file merge download
                UI::redirect('/');
            }
        } else {
            foreach ($files as &$v) {
                $v["file_path"] = ROOT_PATH.DS.$v["file_path"];
            }

            // Create a zip directory
            UI::fs()->createFolder(TMP_PATH . '_zip');
            $zip_path = TMP_PATH . '_zip' . DS . $id . '.zip';
            $count = 0;
            // Determining the existence of a file/Create a zip file
            if (!file_exists($zip_path)) {
                $zip = null;
                foreach ($files as $name => $file) {
                    // Whether or not a ZipArchive object is instantiated.
                    if (!$zip) {
                        $zip = new \ZipArchive();
                        // Open the zip package
                        $zip->open($zip_path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
                    }
                    // Add the file to the zip package.
                    $zip->addFile($file["file_path"], $file["old_name"]);
                    $count++;
                }
                if ($zip) {
                    // Close zip package
                    $zip->close();
                }
            }
            
            self::deldir(TMP_PATH.'_file');

            header("Cache-Control: public");
            header("Content-Description: File Transfer");
            header('Content-Disposition: attachment; filename=' . md5($id).'.zip');
            header("Content-Type: application/zip");
            header("Content-Transfer-Encoding: binary");
            header('Content-Length: ' . filesize($zip_path));
            // No speed limit
            ob_clean();
            flush();
            @readfile($zip_path);


            unlink($zip_path);
        }
    }


    // filesystem
    public static function filesystem($config_storage, $fs=true)
    {
        if ($config_storage["upload_type"] == "s3") {
            $data = $config_storage["s3"];
        }
        if ($config_storage["upload_type"] == "wasabi") {
            $data = $config_storage["wasabi"];
        }
        $config = [
            'scheme'=>'http',
            'version' => 'latest',
            'credentials' => array(
                'key'    => $data["key"],
                'secret' => $data["secret"],
            ),
            'region' => $data["region"],
            'bucket' => $data["bucket"],
        ];

        if ($config_storage["upload_type"] == "wasabi") {
            $config['endpoint'] = "http://s3.".$data["region"].".wasabisys.com/";
        }

        $client = S3Client::factory($config);
        if ($fs) {
            $adapter = new AwsS3Adapter($client, $config['bucket']);

            $filesystem = new Filesystem($adapter);
    
            return $filesystem;
        } else {
            return $client;
        }
    }
}
