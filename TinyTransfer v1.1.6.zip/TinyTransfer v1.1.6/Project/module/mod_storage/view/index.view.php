<link rel="stylesheet" href="/module/mod_storage/assets/css/style.css">

<div class="card flex flex-center">
    <div class="card-body">
        <ul class="tab">
            <li class="tab-item active">
                <a><i class="iconfont icon-shezhi"></i> Storage Settings</a>
            </li>
        </ul>
        
        <div class="flex flex-center">
            <div class="col-5 col-xl-12">
                <form id="modStorageForm">
                    <div class="form-group">
                        <label class="form-radio form-inline">
                            <input type="radio" name="type" value="local" <?php $this->e($upload_type=="local"?"checked":""); ?> ><i class="form-icon"></i> Local
                        </label>
                        <label class="form-radio form-inline">
                            <input type="radio" name="type" value="s3" <?php $this->e($upload_type=="s3"?"checked":""); ?>><i class="form-icon"></i> Aws S3
                        </label>
                        <label class="form-radio form-inline">
                            <input type="radio" name="type" value="wasabi" <?php $this->e($upload_type=="wasabi"?"checked":""); ?>><i class="form-icon"></i> Wasabi
                        </label>
                    </div>

                    <div class="tabs">
                        <fieldset class="columns tab tab-local <?php $this->e($upload_type=="local"?"active":""); ?> "></fieldset>

                        <fieldset class="columns tab tab-s3 <?php $this->e($upload_type=="s3"?"active":""); ?>">
                            <div class="col-12"><hr></div>
                            <div class="column col-12">
                                <div class="form-group">
                                    <label class="form-label">Aws S3 Key</label>
                                    <input name="key" type="text" class="form-input" value="<?php $this->e($s3["key"]); ?>">
                                </div>
                            </div>
                            <div class="column col-12">
                                <div class="form-group">
                                    <label class="form-label">Aws S3 Secret</label>
                                    <input name="secret" type="text" class="form-input" value="<?php $this->e($s3["secret"]); ?>">
                                </div>
                            </div>
                            <div class="column col-12">
                                <div class="form-group">
                                    <label class="form-label">Aws S3 Bucket</label>
                                    <input name="bucket" type="text" class="form-input" value="<?php $this->e($s3["bucket"]); ?>">
                                </div>
                            </div>
                            <div class="column col-12">
                                <div class="form-group">
                                    <label class="form-label">Aws S3 Region</label>
                                    <input name="region" type="text" class="form-input" value="<?php $this->e($s3["region"]); ?>">
                                </div>
                            </div>
                        </fieldset>

                        <fieldset class="columns tab tab-wasabi <?php $this->e($upload_type=="wasabi"?"active":""); ?>">
                            <div class="col-12"><hr></div>
                            <div class="column col-12">
                                <div class="form-group">
                                    <label class="form-label">Wasabi Key</label>
                                    <input name="key" type="text" class="form-input" value="<?php $this->e($wasabi["key"]); ?>">
                                </div>
                            </div>
                            <div class="column col-12">
                                <div class="form-group">
                                    <label class="form-label">Wasabi Secret</label>
                                    <input name="secret" type="text" class="form-input" value="<?php $this->e($wasabi["secret"]); ?>">
                                </div>
                            </div>
                            <div class="column col-12">
                                <div class="form-group">
                                    <label class="form-label">Wasabi Bucket</label>
                                    <input name="bucket" type="text" class="form-input" value="<?php $this->e($wasabi["bucket"]); ?>">
                                </div>
                            </div>
                            <div class="column col-12">
                                <div class="form-group">
                                    <label class="form-label">Wasabi Region</label>
                                    <input name="region" type="text" class="form-input" value="<?php $this->e($wasabi["region"]); ?>">
                                </div>
                            </div>
                        </fieldset>
                    </div>

                    <div class="col-12"><hr></div>

                    <div class="column col-12">
                        <!-- Submit -->
                        <div class="text-center">
                            <button type="button" class="btn btn-primary update-btn">
                            <i class="iconfont icon-save"></i> Save Changes
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script src="/module/mod_storage/assets/js/main.js"></script>