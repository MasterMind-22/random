<?php
use system\UI;

// define module-storage path
define('MODULE_STORAGE_PATH', __DIR__ . DS);

// db init
$config_storage  = UI::database("Config")->where('type', 'storage')->first();
if ($config_storage == null) {
    UI::database("Config")->insert([
        "type" => "storage",
        "upload_type"=>"local",
        "s3"=>[
            "key" => "",
            "secret" => "",
            "region" => "",
            "bucket" => "",
        ],
        "wasabi"=>[
            "key" => "",
            "secret" => "",
            "region" => "",
            "bucket" => "",
        ]
    ]);
}

// add admin menu
add_menu_page('Storage Home', 'Storage', 'storage', function () {
    return \module\storage\Index::index();
}, 'icon-chucun');

/* routes */
UI::route('POST /mod_storage/save', [\module\storage\Index::class, 'save']);
