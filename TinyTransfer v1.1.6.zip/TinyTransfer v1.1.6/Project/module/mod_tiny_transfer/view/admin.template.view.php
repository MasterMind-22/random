<link rel="stylesheet" href="/module/mod_tiny_transfer/assets/css/admin.css">

<div class="card">
	
	<div class="card-body">
		<ul class="tab">
            <li class="tab-item active">
                <a><i class="iconfont icon-wenjian"></i> Email Template (Preview)</a>
            </li>
        </ul>

		<legend>File path: <span class="label label-success">/module/mod_tiny_transfer/view/email.template.view.php</span></legend>
		<div>
			<?php $this->h($html);?>
		</div>
	</div>

</div>
