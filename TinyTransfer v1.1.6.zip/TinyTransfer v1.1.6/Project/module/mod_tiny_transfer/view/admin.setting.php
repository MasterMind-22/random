<link rel="stylesheet" href="/module/mod_tiny_transfer/assets/css/admin.css">

<div class="card flex flex-center setting-info-page">
    <div class="card-body">
        <ul class="tab">
            <li class="tab-item active" data-type="site">
                <a><i class="iconfont icon-seo"></i> Site</a>
            </li>
            <li class="tab-item" data-type="transfer">
                <a><i class="iconfont icon-xianzhiliusu"></i> Upload/Download</a>
            </li>
            <li class="tab-item" data-type="background">
                <a><i class="iconfont icon-beijing"></i> Background</a>
            </li>
            <!-- Next version features
            <li class="tab-item" data-type="theme">
                <a><i class="iconfont icon-beijing"></i> Theme</a>
            </li>
            <li class="tab-item" data-type="ads">
                <a><i class="iconfont icon-beijing"></i> Ads</a>
            </li> -->
        </ul>
        <div class="flex flex-center">
            <div class="col-5 col-xl-12">
                <form id="form">
                    <div class="form-groups tab-panel active"  data-type="site">
                        <!-- Name -->
                        <div class="form-group">
                            <label class="form-label">Title</label>
                            <input class="form-input" type="text" placeholder="Title" name="title"
                                value="<?php $this->e($v["title"]);?>">
                        </div>

                        <!-- Thumbnail -->
                        <div class="form-group">
                            <label class="form-label">Logo(200*200)</label>
                            <div class="from-upload logo-upload">
                                <input type="file">
                                <div class="uploader-input">
                                    <div class="progress-panel">
                                        <div class="file-progress-bar"></div>
                                        <span></span>
                                    </div>
                                    <?php
                                    if (isset($v["logo"])) {
                                        ?>
                                    <div class="preview" style="background-image: url(<?php $this->e($v["logo"]); ?>);">
                                        <input type="hidden" class="img" name="logo"
                                            value="<?php $this->e($v["logo"]); ?>">
                                    </div>
                                    <?php
                                    } else {?>
                                    <div class="preview">
                                        <input type="hidden" class="img" name="logo">
                                    </div>
                                    <?php }?>
                                    <span class="bf">Browse files</span>
                                </div>

                            </div>
                        </div>


                        <!-- Description -->
                        <div class="form-group">
                            <label class="form-label">Description</label>
                            <textarea class="form-input" name="description" placeholder="Description"
                                rows="3"><?php $this->e($v["description"]);?></textarea>
                        </div>

                        <!-- Keywords -->
                        <div class="form-group">
                            <label class="form-label">Keywords</label>
                            <textarea class="form-input" name="keywords" placeholder="Keywords"
                                rows="3"><?php $this->e($v["keywords"]);?></textarea>
                        </div>
                        
                    </div>

                    <div class="form-groups tab-panel" data-type="transfer">
                        <!-- Max Upload -->
                        <div class="form-group">
                            <label class="form-label">Maximum upload(Single)</label>
                            <div class="input-group">
                                <div class="col-8">
                                    <input class="form-input" type="text" name="max_upload_single" value="<?php $this->e($v["max_upload_single"]);?>">
                                </div>
                                <select class="form-select" name="max_upload_single_unit">
                                    <option <?php $this->e($v["max_upload_single_unit"]=="KB"?"selected":""); ?>>KB</option>
                                    <option <?php $this->e($v["max_upload_single_unit"]=="MB"?"selected":""); ?>>MB</option>
                                    <option <?php $this->e($v["max_upload_single_unit"]=="GB"?"selected":""); ?>>GB</option>
                                </select>
                            </div>
                        </div>

                         <!-- Max Upload -->
                        <div class="form-group">
                            <label class="form-label">Maximum upload(Multiple)</label>
                            <div class="input-group">
                                <div class="col-8">
                                    <input class="form-input" type="text" name="max_upload_multiple" value="<?php $this->e($v["max_upload_multiple"]);?>">
                                </div>
                                <select class="form-select" name="max_upload_multiple_unit">
                                    <option <?php $this->e($v["max_upload_multiple_unit"]=="KB"?"selected":""); ?>>KB</option>
                                    <option <?php $this->e($v["max_upload_multiple_unit"]=="MB"?"selected":""); ?>>MB</option>
                                    <option <?php $this->e($v["max_upload_multiple_unit"]=="GB"?"selected":""); ?>>GB</option>
                                </select>
                            </div>
                        </div>

                        <!-- Download Speed Limit 
                        <div class="form-group">
                            <label class="form-label">Download Speed Limit</label>
                            <div class="input-group">
                                <div class="col-8">
                                    <input class="form-input" type="text" name="download_speed_limit" value="<?php $this->e($v["download_speed_limit"]);?>">
                                </div>
                                <select class="form-select" name="download_speed_limit_unit">
                                    <option <?php $this->e($v["download_speed_limit_unit"]=="KB"?"selected":""); ?>>KB</option>
                                    <option <?php $this->e($v["download_speed_limit_unit"]=="MB"?"selected":""); ?>>MB</option>
                                    <option <?php $this->e($v["download_speed_limit_unit"]=="GB"?"selected":""); ?>>GB</option>
                                </select>
                            </div>
                        </div>-->
                        
                    </div>

                    <div class="form-groups tab-panel"  data-type="background">

                        <!-- background -->
                        <div class="form-group">
                            <label class="form-label">Background(Image*Video)</label>
                            <div class="from-upload background-upload">
                                
                                <input type="file">
                                <a class="bg-close close-btn"><i class="iconfont icon-delete"></i></a>
                                <div class="uploader-input">
                                    <div class="progress-panel">
                                        <div class="file-progress-bar"></div>
                                        <span></span>
                                    </div>
                                    <?php
                                    if (isset($v["background"])) {
                                        function get_extension($file)
                                        {
                                            return substr($file, strrpos($file, '.')+1);
                                        }
                                        $ext = empty($v["background"]) ? '': get_extension($v["background"]); ?>
                                    <div class="preview">
                                        
                                        <div class="preview-item">
                                            
                                            <img class="<?php $this->e(($ext=="png"||$ext=="jpg"||$ext=="jpeg")?"show":"hide"); ?>" src="<?php $this->e($v["background"]); ?>">

                                            <video class="<?php $this->e(($ext=="mp4")?"show":"hide"); ?>">
                                                <source src="<?php $this->e($v["background"]); ?>" type="video/mp4" />
                                            </video>

                                        </div>
                                        <input type="hidden" class="img" name="background" value="<?php $this->e($v["background"]); ?>">
                                    </div>
                                    <?php
                                    } else {?>
                                    <div class="preview">
                                        <input type="hidden" class="img" name="background">
                                    </div>
                                    <?php }?>
                                    <span class="bf">Browse files</span>
                                </div>

                            </div>
                            <div class="has-error">
                                <p class="form-input-hint">Recommended for large images and super high definition video.</p>
                            </div>
                        </div>
                        
                    </div>
                    <!-- hr -->
                    <div class="col-12">
                        <hr>
                    </div>

                    
                    <!-- Submit -->
                    <div class="col-12 text-center">
                        <button type="button" class="btn btn-primary save">
                            <i class="iconfont icon-save"></i> Save Changes
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>

<script src="/module/mod_tiny_transfer/assets/js/admin.uploader.js"></script>
<script src="/module/mod_tiny_transfer/assets/js/admin.setting.js"></script>