<?php

return [
    "name" => "module_tiny_transfer",
    "open" => true
];
