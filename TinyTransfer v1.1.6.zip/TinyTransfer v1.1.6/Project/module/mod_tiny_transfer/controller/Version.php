<?php

namespace module\tinyTransfer;

use system\UI;

/**
 * Version
 */
class Version
{
    protected static $config;

    /**
     * get config
     */
    public static function get_config()
    {
        self::$config = UI::database("Config")->where('type', 'tiny_transfer_setting')->first();
    }
    /**
     * init
     */
    public static function init()
    {
        self::get_config();
        if (self::$config == null) {
            self::insert();
        } else {
            self::update();
        }
    }

    /**
     * insert init db
     */
    public static function insert()
    {
        UI::database("Config")->insert([
            "version"=>MODULE_TINYTRANSFER_VERSION,
            "type" => "tiny_transfer_setting",
            'title' => "TinyTransfer",
            'logo' => "/module/mod_tiny_transfer/assets/img/logo.png",
            'description' => "Tiny Transfer is the simplest way to send your files around the world",
            'keywords' => "Tiny,Transfer,file,send,zip,upload,download",
            'max_upload_single' => '',
            'max_upload_single_unit' => 'KB',
            'max_upload_multiple' => '',
            'max_upload_multiple_unit' => 'KB',
            'download_speed_limit' => '',
            'download_speed_limit_unit' => 'KB',
            'background' => '',
        ]);
    }

    /**
     * update
     */
    public static function update()
    {
        if (isset(self::$config["version"])) {
            // version update
        } else {
            // old
            UI::database("Config")->where('type', 'tiny_transfer_setting')->update([
                "version"=>MODULE_TINYTRANSFER_VERSION,
                'max_upload_single' => '',
                'max_upload_single_unit' => 'KB',
                'max_upload_multiple' => '',
                'max_upload_multiple_unit' => 'KB',
                'download_speed_limit' => '',
                'download_speed_limit_unit' => 'KB',
                'background' => '',
            ]);
        }
    }
}
