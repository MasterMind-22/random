jQuery(function() {
    //tab
    if (jQuery(".tab-item").length >= 2) {
        jQuery('.tab-item').on("click", function() {
            jQuery('.tab-item,.tab-panel').removeClass("active");
            jQuery(this).addClass("active");
            let _type = jQuery(this).attr("data-type");
            jQuery('.tab-panel').each(function() {
                if (jQuery(this).attr("data-type") == _type) {
                    jQuery(this).addClass("active");
                }
            });
        });
    }
});