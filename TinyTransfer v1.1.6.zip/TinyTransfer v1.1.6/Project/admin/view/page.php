<?php require __DIR__ . "/public_header.php";?>

<div class="pages">
	<?php $this->h($html); ?>
</div>

<?php require __DIR__ . "/public_footer.php";?>