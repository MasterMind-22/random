			</div>
		</main>
		<script src="/admin/assets/js/init.js"></script>
	</body>
</html>